package com.mycompany.veterinariapoo;

public class VeterinariaPOO {
    public static void main(String[] args) {
        Animal animal1 = new Animal("Animalito", 3);
        animal1.hacerSonido();

        Perro perro1 = new Perro("Firulais", 5, "Labrador");
        perro1.hacerSonido();

        System.out.println("Nombre: " + perro1.getNombre());
        System.out.println("Edad: " + perro1.getEdad());
        System.out.println("Raza: " + perro1.getRaza());
    }
}
